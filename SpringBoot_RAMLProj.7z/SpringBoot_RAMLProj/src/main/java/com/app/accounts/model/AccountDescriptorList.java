
package com.app.accounts.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class AccountDescriptorList implements Serializable
{

    final static long serialVersionUID = -9161261303273961588L;
    private List<AccountDescriptor> accountDescriptor = new ArrayList<AccountDescriptor>();

    /**
     * Creates a new AccountDescriptorList.
     * 
     */
    public AccountDescriptorList() {
        super();
    }

    /**
     * Creates a new AccountDescriptorList.
     * 
     */
    public AccountDescriptorList(List<AccountDescriptor> accountDescriptor) {
        super();
        this.accountDescriptor = accountDescriptor;
    }

    /**
     * Returns the accountDescriptor.
     * 
     * @return
     *     accountDescriptor
     */
    public List<AccountDescriptor> getAccountDescriptor() {
        return accountDescriptor;
    }

    /**
     * Set the accountDescriptor.
     * 
     * @param accountDescriptor
     *     the new accountDescriptor
     */
    public void setAccountDescriptor(List<AccountDescriptor> accountDescriptor) {
        this.accountDescriptor = accountDescriptor;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(accountDescriptor).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        AccountDescriptorList otherObject = ((AccountDescriptorList) other);
        return new EqualsBuilder().append(accountDescriptor, otherObject.accountDescriptor).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("accountDescriptor", accountDescriptor).toString();
    }

}
