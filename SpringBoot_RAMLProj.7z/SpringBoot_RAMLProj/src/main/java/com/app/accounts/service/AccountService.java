package com.app.accounts.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.app.accounts.model.AccountDescriptor;


@Service
public interface AccountService {
	public List<AccountDescriptor> getAccounts();

}
