package com.app.accounts.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import com.app.accounts.model.Error;

@ControllerAdvice
public class CustomizedExceptionHandler extends ResponseEntityExceptionHandler {

	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler
	public ResponseEntity<Error> handleException(AccountNotFoundException ane) {
		Error errorResponse = new Error();

		return new ResponseEntity<Error>(new Error("404", "Resource not found,check the url"), HttpStatus.NOT_FOUND);
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(value = BadRequestException.class)
	public ResponseEntity<Error> badRequestException(BadRequestException ex) {
		return new ResponseEntity<Error>(new Error("400", "Invalid request   "), HttpStatus.BAD_REQUEST);
	}

}
